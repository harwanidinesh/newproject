<?php 
namespace KTree\CustomerAttribute\Observer; 
use Magento\Framework\Event\ObserverInterface; 
use Psr\Log\LoggerInterface; 
class OrdedataObserver implements ObserverInterface 
{ 
	protected $logger; 
	public function __construct(LoggerInterface $logger, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository) 
	{ 
		$this->logger = $logger;
		$this->customerRepository = $customerRepository;
	}
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		try 
		{
			$order = $observer->getEvent()->getOrder();
			$customer = $this->getCustomer($order->getCustomerId());
			if($customer->getIsNew() == 1)
			{
				$customer->setIsNew(0);
				$this->customerRepository->save($customer);
			}
		}
		catch (\Exception $e) 
		{
			$this->logger->info($e->getMessage());
		}
	}
  /* Pass customer id $id*/
	public function getCustomer($id)
	{ 
		return $this->customerRepository->getById($id);
	}
}