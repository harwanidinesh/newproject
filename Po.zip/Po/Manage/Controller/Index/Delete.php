<?php

namespace Po\Manage\Controller\Index;

use Magento\Framework\Exception\NotFoundException;
use Magento\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Po\Manage\Api\DealerRepositoryInterface;

class Delete extends \Magento\Framework\App\Action\Action
{

    /**
     * @var DealerRepositoryInterface
     */
    private $dealerRepository;

    /**
     * @param Action\Context $context
     * @param DealerRepositoryInterface $dealerRepository
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        DealerRepositoryInterface $dealerRepository
    ) {
        parent::__construct($context);

        $this->dealerRepository = $dealerRepository;
    }

    /**
     * @return ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $this->dealerRepository->deleteById($id);
                $this->messageManager->addSuccessMessage(__('The Dealer has been deleted.'));

                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());

                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addErrorMessage(__('We can\'t find a Dealer to delete.'));

        return $resultRedirect->setPath('*/*/');
    }
}
