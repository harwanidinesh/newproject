<?php

namespace Po\Manage\Controller\Index;

use Magento\Framework\App\Action\Context;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Api\PoRepositoryInterface;
use Po\Manage\Model\Po;
use Po\Manage\Model\PoFactory;
use Po\Manage\Api\Data\PoItemInterface;
use Po\Manage\Api\PoItemRepositoryInterface;
use Po\Manage\Model\PoItem;
use Po\Manage\Model\PoItemFactory;
use Po\Manage\Model\ResourceModel\Po\CollectionFactory as PoCollectionFactory;
use Po\Manage\Model\PurchaseIdFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Session\SessionManagerInterface;

class Save extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Po
     */
    protected $_po;

    public function __construct(
		Context $context,
        PoRepositoryInterface $poRepository,
        PoFactory $po,
        PoItemRepositoryInterface $poItemRepository,
        PoItemFactory $poItem,
        PoCollectionFactory $poCollectionFactory,
        PurchaseIdFactory $purchaseIdobjFactory,
        ScopeConfigInterface $scopeConfig,
        Session $session,
        SessionManagerInterface $coreSession
    ) {
        $this->_po = $po;
        $this->poRepository = $poRepository;
        $this->_poItem = $poItem;
        $this->poItemRepository = $poItemRepository;
        $this->poCollectionFactory = $poCollectionFactory;
        $this->purchaseIdobjFactory = $purchaseIdobjFactory;
        $this->scopeConfig = $scopeConfig;
        $this->_customerSession = $session;
        $this->_coreSession = $coreSession;
        parent::__construct($context);
    }

	public function execute()
    {
        $data = $this->getRequest()->getParams();
        $purchase_id='';
        if ($this->_customerSession->isLoggedIn()) 
        {
	        if($this->scopeConfig->getValue('manage_po/pur_order/enabled', \Magento\Store\Model\ScopeInterface::SCOPE_STORE) ==1)
	    	{
	    		$incNo = $this->scopeConfig->getValue('manage_po/purchaseorder_grp/startfrom', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
	    		if($incNo)
	    		{
		        	$purchaseIdObj = $this->purchaseIdobjFactory->create()->load(1);

				    if(!$purchaseIdObj->getStartup())
				    {
				    	$purchaseIdObj = $this->purchaseIdobjFactory->create();
				    	$purchaseIdObj->setData(array("startup"=>$incNo,"currentid"=>$incNo))->save();
				    }
				    else
				    {
				    	if($purchaseIdObj->getData("startup") != $incNo){
				    		$purchaseIdObj->setStartup($incNo);
				    		$purchaseIdObj->setCurrentid($incNo);
				    		$purchaseIdObj->save();
					    }
					    else
					    {
					    	$incNo = (int)$purchaseIdObj->getData("currentid")+1;
				    		$purchaseIdObj->setCurrentid($incNo);
				    		$purchaseIdObj->save();
					    }

				    }

			        $prefix = $this->scopeConfig->getValue('manage_po/purchaseorder_grp/prefix', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			        $postfix = $this->scopeConfig->getValue('manage_po/purchaseorder_grp/postfix', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);

			        $purchase_id = $prefix.$incNo.$postfix;
			    }
			}
	    	$po = $this->_po->create();
	    	$poData[PoInterface::KEY_PUR_ID]=$purchase_id;
	    	$poData[PoInterface::KEY_DEALER_ID]=$data['dealer_id'];
	    	$poData[PoInterface::KEY_DEALER_NAME]=$data['dealer_name'];
	    	$poData[PoInterface::KEY_CUSTOMER_ID]=$this->_customerSession->getCustomer()->getId();
	        $poData[PoInterface::KEY_STATUS]='Raised';
	        $po->setData($poData);
	        if($new_po = $this->poRepository->save($po))
	        {
	        	$poItem =[];
	        	$totalItem =0;
	            foreach($data['po_product_id'] as $key => $value)
	            {
	            	$poItem = $this->_poItem->create();
	            	$poItemData[PoItemInterface::KEY_PUR_ID] = $new_po->getId();
	            	$poItemData[PoItemInterface::KEY_PRODUCT_ID] = $value;
	            	$poItemData[PoItemInterface::KEY_PRODUCT_SKU] = $data['po_product_sku'][$value];
	            	$poItemData[PoItemInterface::KEY_PRODUCT_NAME] =$data['po_product_name'][$value];
	            	$poItemData[PoItemInterface::KEY_QTY] = $data['po_product_qty'][$value];
	            	$poItemData[PoItemInterface::KEY_REMARKS] = $data['po_product_remarks'][$value];
	            	$poItem->setData($poItemData);
	        		if($new_poItem = $this->poItemRepository->save($poItem))
	        		{
	        			$totalItem = $totalItem+1;
	        		}
	            }
	            if($totalItem == count($data['po_product_id']))
	            {
	            	$this->messageManager->addSuccessMessage(__('You saved the data.'));
	            	$this->_coreSession->setPurchaseId($new_po->getId());
                    $this->_coreSession->setLastRealPo($new_po);
	            }
	            $resultRedirect = $this->resultRedirectFactory->create();
	        	$resultRedirect->setPath('pur/index/success');
	        }
	        else
	        {
	            $this->messageManager->addErrorMessage(__('Data was not saved.'));
	            $resultRedirect = $this->resultRedirectFactory->create();
	        	$resultRedirect->setPath('*/*/*');
	        }
	    }
	    else
	    {
	    	$this->messageManager->addErrorMessage(__('Customer is not LoggedIn'));
	    	$resultRedirect = $this->resultRedirectFactory->create();
	        $resultRedirect->setPath('customer/account/login');
	    }
        return $resultRedirect;
    }
}
