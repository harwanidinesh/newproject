<?php

namespace Po\Manage\Controller\Index;

use Magento\Framework\App\Action\Context;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Api\DealerRepositoryInterface;
use Po\Manage\Model\Dealer;
use Po\Manage\Model\DealerFactory;
use Magento\Framework\Filesystem;

class Save extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Dealer
     */
    protected $_dealer;

    public function __construct(
		Context $context,
        DealerRepositoryInterface $dealerRepository,
        DealerFactory $dealer
    ) {
        $this->_dealer = $dealer;
        $this->dealerRepository = $dealerRepository;
        parent::__construct($context);
    }
	public function execute()
    {
        $data = $this->getRequest()->getParams();
    	$dealer = $this->_dealer->create();
        $data[DealerInterface::KEY_STATUS]='1';
        $dealer->setData($data);
        if($this->dealerRepository->save($dealer)){
            $this->messageManager->addSuccessMessage(__('You saved the data.'));
        }else{
            $this->messageManager->addErrorMessage(__('Data was not saved.'));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('dealer');
        return $resultRedirect;
    }
}
