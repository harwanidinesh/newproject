<?php
namespace Po\Manage\Controller\Index;

class Editdata   extends \Magento\Framework\App\Action\Action
{
  protected $_timezoneInterface;
  public function __construct(\Magento\Framework\App\Action\Context $context, \Po\Manage\Api\PoRepositoryInterface $poRepository, \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface) {
        parent::__construct($context);
        $this->poRepository = $poRepository;
        $this->_timezoneInterface = $timezoneInterface;
  }
  public function execute()
  {
      $data = $this->getRequest()->getParams();
      if($data){
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      $customerSession = $objectManager->get('Magento\Customer\Model\Session');
      $resultRedirect = $this->resultRedirectFactory->create();
      if($customerSession->isLoggedIn()) {
        $postCollection = $objectManager->create('Po\Manage\Model\Po')->load($data['id']);
        $postuser = $postCollection->getCustomerId();
        $loginuser = $customerSession->getCustomer()->getId();
        if($postuser == $loginuser){
          $postCollection->setData($data);
          if($new_po = $this->poRepository->save($postCollection))
	        {
                $this->messageManager->addSuccess(__("Po Successfully Edit."));
                return $resultRedirect->setPath('pur/index/list');
            }
        }else{
        $this->messageManager->addError(__("Somthing Wrong. Please Try Again."));
        return $resultRedirect->setPath('pur/index/list');
        }
      }else{
        $this->messageManager->addError(__("Somthing Wrong. Please Try Again."));
        return $resultRedirect->setPath('pur/index/list');
      }
    }else{
      $this->messageManager->addError(__("Somthing Wrong. Please Try Again."));
      return $resultRedirect->setPath('pur/index/list');
    }
  }
}
