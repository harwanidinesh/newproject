<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Po\Manage\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\NotFoundException;
use Po\Manage\Block\Success as SuccessView;

/**
 * Onepage checkout success controller class
 */
class Success extends \Magento\Framework\App\Action\Action
{

	public function __construct(
        Context $context
    ) {
        parent::__construct($context);
    }

	public function execute()
    {	
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
    }
}
