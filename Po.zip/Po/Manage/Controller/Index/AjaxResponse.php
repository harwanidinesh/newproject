<?php
namespace Po\Manage\Controller\Index;

class AjaxResponse extends \Magento\Framework\App\Action\Action
{
	protected $_productCollectionFactory;
	
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
	    parent::__construct($context);
		$this->_productCollectionFactory = $productCollectionFactory;
	    $this->resultJsonFactory = $resultJsonFactory;
		
	}

	public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        $productCollection = $this->getProductCollections();
		$product_details = [];
		$success = "Error";
		if($productCollection->getSize()>0)
		{
            $i=0;
			foreach ($productCollection as $product) {
				$product_details[$i]['product_id'] = $product->getId();
                $product_details[$i]['product_name'] = $product->getName();
                $product_details[$i]['product_sku'] = $product->getSku();
                $i++;
			}
			$success = "Success";
		}
        return $resultJson->setData([
            'product_details' => $product_details,
            'success' => $success
        ]);
    }
	public function getProductCollections()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->setPageSize(5); // fetching only 3 products
        return $collection;
    }
}
