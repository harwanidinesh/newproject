<?php
namespace Po\Manage\Controller\Index;

class AjaxResponse extends \Magento\Framework\App\Action\Action
{
	protected $_productCollectionFactory;
	
	public function __construct(
	    \Magento\Framework\App\Action\Context $context,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
	    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	) {
	    parent::__construct($context);
		$this->_productCollectionFactory = $productCollectionFactory;
	    $this->resultJsonFactory = $resultJsonFactory;
		
	}

	public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        $productCollection = $this->getProductCollections();
		$htmlContent = "";
		$success = "Error";
		if($productCollection->getSize()>0)
		{
			foreach ($productCollection as $product) {
				$htmlContent = $htmlContent. "<tr>
								<td><input type='checkbox' name='product_id[".$product->getId()."]'></td>
								<td>".$product->getSku()."</td><td>".$product->getName()."</td>
								</tr>";
			}
			$success = "Success";
		}
        return $resultJson->setData([
            'html' => $htmlContent,
            'success' => $success
        ]);
    }
	public function getProductCollections()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->setPageSize(3); // fetching only 3 products
        return $collection;
    }
}