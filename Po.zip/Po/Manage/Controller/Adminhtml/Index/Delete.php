<?php

namespace Po\Manage\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Po\Manage\Api\PoRepositoryInterface;

class Delete extends Action
{
    const ADMIN_RESOURCE = 'Po_Manage::delete';

    /**
     * @var PoRepositoryInterface
     */
    private $poRepository;

    /**
     * @param Action\Context $context
     * @param PoRepositoryInterface $poRepository
     */
    public function __construct(
        Action\Context $context,
        PoRepositoryInterface $poRepository
    ) {
        parent::__construct($context);

        $this->poRepository = $poRepository;
    }

    /**
     * @return ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $this->poRepository->deleteById($id);
                $this->messageManager->addSuccessMessage(__('The Po has been deleted.'));

                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());

                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addErrorMessage(__('We can\'t find a Po to delete.'));

        return $resultRedirect->setPath('*/*/');
    }
}
