<?php

namespace Po\Manage\Controller\Adminhtml\Index;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Api\DealerRepositoryInterface;
use Po\Manage\Model\DealerFactory;

class Edit extends Action
{
    const ADMIN_RESOURCE = 'Po_Manage::dealer';

    /**
     * @var dealerRepositoryInterface
     */
    private $dealerRepository;

    /**
     * @var dealerFactory
     */
    private $dealerFactory;

    /**
     * @param Context $context
     * @param dealerRepositoryInterface $dealerRepository
     * @param dealerFactory $dealerFactory
     */
    public function __construct(
        Context $context,
        dealerRepositoryInterface $dealerRepository,
        dealerFactory $dealerFactory
    ) {
        parent::__construct($context);
        $this->dealerRepository = $dealerRepository;
        $this->dealerFactory = $dealerFactory;
    }


    /**
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        if ($id) {
            try {
                /** @var dealerInterface $model */
                $model = $this->dealerRepository->getById($id);
            } catch (Exception $exception) {
                $this->messageManager->addErrorMessage(__('This Dealer no longer exists.'));
                $this->_redirect('dealer/*');

                return;
            }
        } else {
            $model = $this->dealerFactory->create();
        }

        $this->_initAction();
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Dealers'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getId() ? __("Edit Dealer '%1'", $model->getId()) : __('New Dealer')
        );

        $breadcrumb = $id ? __('Edit Rule') : __('New Rule');
        $this->_addBreadcrumb($breadcrumb, $breadcrumb);
        $this->_view->renderLayout();
    }

    /**
     * @return $this
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu('Po_Manage::dealer');

        return $this;
    }
}
