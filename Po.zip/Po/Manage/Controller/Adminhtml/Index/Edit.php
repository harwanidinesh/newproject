<?php

namespace Po\Manage\Controller\Adminhtml\Index;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Api\PoRepositoryInterface;
use Po\Manage\Model\PoFactory;

class Edit extends Action
{
    const ADMIN_RESOURCE = 'Po_Manage::po';

    /**
     * @var poRepositoryInterface
     */
    private $poRepository;

    /**
     * @var poFactory
     */
    private $poFactory;

    /**
     * @param Context $context
     * @param poRepositoryInterface $poRepository
     * @param poFactory $poFactory
     */
    public function __construct(
        Context $context,
        poRepositoryInterface $poRepository,
        poFactory $poFactory
    ) {
        parent::__construct($context);
        $this->poRepository = $poRepository;
        $this->poFactory = $poFactory;
    }


    /**
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');

        if ($id) {
            try {
                /** @var poInterface $model */
                $model = $this->poRepository->getById($id);
            } catch (Exception $exception) {
                $this->messageManager->addErrorMessage(__('This Po no longer exists.'));
                $this->_redirect('po/*');

                return;
            }
        } else {
            $model = $this->poFactory->create();
        }

        $this->_initAction();
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Pos'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getId() ? __("Edit Po '%1'", $model->getId()) : __('New Po')
        );

        $breadcrumb = $id ? __('Edit Rule') : __('New Rule');
        $this->_addBreadcrumb($breadcrumb, $breadcrumb);
        $this->_view->renderLayout();
    }

    /**
     * @return $this
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu('Po_Manage::po');

        return $this;
    }
}
