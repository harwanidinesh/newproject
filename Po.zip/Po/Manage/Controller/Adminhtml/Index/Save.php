<?php

namespace Po\Manage\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Api\PoRepositoryInterface;
use Po\Manage\Model\Po;
use Po\Manage\Model\PoFactory;
use Throwable;

class Save extends Action
{
    const ADMIN_RESOURCE = 'Po_Manage::save';

    /**
     * @var PoRepositoryInterface
     */
    private $poRepository;

    /**
     * @var PoFactory
     */
    private $poFactory;

    /**
     * @param Action\Context $context
     * @param PoRepositoryInterface $poRepository
     * @param PoFactory $poFactory
     */
    public function __construct(
        Action\Context $context,
        PoRepositoryInterface $poRepository,
        PoFactory $poFactory
    ) {
        parent::__construct($context);
        $this->poRepository = $poRepository;
        $this->poFactory = $poFactory;
    }

    /**
     * @return ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $data = $this->getRequest()->getParams();
        /** @var Po $po */
        if ($id) {
            $po = $this->poRepository->getById($id);
        } else {
            unset($data[PoInterface::KEY_ID]);
            $po = $this->poFactory->create();
        }

        unset($data[PoInterface::KEY_UPDATED_AT]);
        $po->setData($data);

        try {
            $this->poRepository->save($po);
            $this->messageManager->addSuccessMessage(__('Record saved successfully'));

            if (key_exists('back', $data) && $data['back'] == 'edit') {

                return $resultRedirect->setPath('*/*/edit', ['id' => $id, '_current' => true]);
            }

            return $resultRedirect->setPath('*/*/');
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__("Record not saved".$e->getMessage()));

            return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
        }
    }
}
