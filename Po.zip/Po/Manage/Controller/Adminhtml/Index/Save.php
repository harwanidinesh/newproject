<?php

namespace Po\Manage\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Api\DealerRepositoryInterface;
use Po\Manage\Model\Dealer;
use Po\Manage\Model\DealerFactory;
use Throwable;

class Save extends Action
{
    const ADMIN_RESOURCE = 'Po_Manage::save';

    /**
     * @var DealerRepositoryInterface
     */
    private $dealerRepository;

    /**
     * @var DealerFactory
     */
    private $dealerFactory;

    /**
     * @param Action\Context $context
     * @param DealerRepositoryInterface $dealerRepository
     * @param DealerFactory $dealerFactory
     */
    public function __construct(
        Action\Context $context,
        DealerRepositoryInterface $dealerRepository,
        DealerFactory $dealerFactory
    ) {
        parent::__construct($context);
        $this->dealerRepository = $dealerRepository;
        $this->dealerFactory = $dealerFactory;
    }

    /**
     * @return ResultInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        $data = $this->getRequest()->getParams();
        /** @var Dealer $dealer */
        if ($id) {
            $dealer = $this->dealerRepository->getById($id);
        } else {
            unset($data[DealerInterface::KEY_ID]);
            $dealer = $this->dealerFactory->create();
        }

        unset($data[DealerInterface::KEY_UPDATED_AT]);
        $dealer->setData($data);

        try {
            $this->dealerRepository->save($dealer);
            $this->messageManager->addSuccessMessage(__('Record saved successfully'));

            if (key_exists('back', $data) && $data['back'] == 'edit') {

                return $resultRedirect->setPath('*/*/edit', ['id' => $id, '_current' => true]);
            }

            return $resultRedirect->setPath('*/*/');
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__("Record not saved".$e->getMessage()));

            return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
        }
    }
}
