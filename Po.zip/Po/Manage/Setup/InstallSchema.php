<?php

namespace Po\Manage\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws \Zend_Db_Exception
     */
    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->startSetup();
        $this->_createCategoryTable($setup);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     */
    private function _createCategoryTable($setup)
    {
        /** @var \Magento\Framework\DB\Adapter\AdapterInterface $connection */
        $connection = $setup->getConnection();
        $tableName = 'magento_dealer_master1';

        if (!$setup->tableExists($tableName)) {
            $table = $connection->newTable($setup->getTable($tableName))
                ->addColumn(
                    'id', Table::TYPE_INTEGER, null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary'  => true,
                        'unsigned' => true,
                    ], 'ID'
                )
                ->addColumn(
                    'first_name', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Book Type'
                )
                ->addColumn(
                    'last_name', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Name'
                )
                ->addColumn(
                    'dealer_name', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Dealer Name'
                )
                ->addColumn(
                    'address', Table::TYPE_TEXT, 2000, ['nullable' => false],
                    'address'
                )
                ->addColumn(
                    'city', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'City'
                )
                ->addColumn(
                    'state', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'State'
                )
                ->addColumn(
                    'country', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Country'
                )
                ->addColumn(
                    'email', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Email'
                )
                ->addColumn(
                    'phone_number', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Phone Number'
                )
                ->addColumn(
                    'fax', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Fax'
                )
                ->addColumn(
                    'pan_number', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Pan Number'
                )
                ->addColumn(
                    'status', Table::TYPE_SMALLINT, null, ['nullable' => false, 'unsigned' => true, 'default' => 0],
                    'Status'
                )
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                    'Creation Time'
                )
                ->addColumn(
                    'updated_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
                    'Modification Time'
                )
                ->setComment('Delears Table');

            $connection->createTable($table);
        }
    }
}
