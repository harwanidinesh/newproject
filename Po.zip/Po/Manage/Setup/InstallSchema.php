<?php

namespace Po\Manage\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws \Zend_Db_Exception
     */
    public function install(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->startSetup();
        $this->_createCategoryTable($setup);
        $setup->endSetup();
    }

    /**
     * @param SchemaSetupInterface $setup
     * @throws \Zend_Db_Exception
     */
    private function _createCategoryTable($setup)
    {
        /** @var \Magento\Framework\DB\Adapter\AdapterInterface $connection */
        $connection = $setup->getConnection();
        $tableName = 'po_table';

        if (!$setup->tableExists($tableName)) 
        {
            $table = $connection->newTable($setup->getTable($tableName))
                ->addColumn(
                    'id', Table::TYPE_INTEGER, null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary'  => true,
                        'unsigned' => true,
                    ], 'ID'
                )
                ->addColumn(
                    'purchase_id', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Po'
                )
                ->addColumn(
                    'dealer_id', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Dealer id'
                )
                ->addColumn(
                    'dealer_name', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Dealer Name'
                )
                ->addColumn(
                    'customer_id', Table::TYPE_TEXT, 2000, ['nullable' => false],
                    'Customer id'
                )
                ->addColumn(
                    'status', Table::TYPE_TEXT, 255, ['nullable' => false],
                    'Status'
                )
               
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                    'Creation Time'
                )
                ->addColumn(
                    'updated_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
                    'Modification Time'
                )
                ->setComment('Po table');
            $connection->createTable($table);    
            
        }

        if (!$setup->tableExists('po_custompurchaseorder')) 
        {
            $table = $connection->newTable($setup->getTable('po_custompurchaseorder'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['auto_increment' => true,'identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'startup',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null],
                    'StartUp'
                )
                ->addColumn(
                    'currentid',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['default' => null],
                    'Currentid'
                );
            $connection->createTable($table);
        }
		
		 if (!$setup->tableExists('po_item_table')) 
        {
            $table = $connection->newTable($setup->getTable('po_item_table'))
                ->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    ['auto_increment' => true,'identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Id'
                )
                ->addColumn(
                    'purchase_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['nullable' => false],
                    'purchase id'
                )
                ->addColumn(
                    'product_id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['nullable' => false],
                    'product id'
                )
				->addColumn(
                    'product_sku',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['nullable' => false],
                    'product sku'
                )
				->addColumn(
                    'product_name',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
                    ['nullable' => false],
                    'product name'
                )
				->addColumn(
                    'qty',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
					['nullable' => false],
                    'qty'
                )
				->addColumn(
                    'remarks',
                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    255,
					['nullable' => false],
                    'Remarks'
                );
            $connection->createTable($table);
        }
    }
}
