<?php

namespace Po\Manage\Model;

use Magento\Framework\Model\AbstractModel;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Model\ResourceModel\Po as ResourceModel;

class Po extends AbstractModel implements PoInterface
{
    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'sc_po';

    /**
     * Parameter name in event
     * In observe method you can use $observer->getEvent()->getRule() in this case
     *
     * @var string
     */
    protected $_eventObject = 'po';
    
    /**
     * @return string
     */
    public function getPurchaseId()
    {
        return $this->getData(self::KEY_PUR_ID);
    }

    /**
     * @return string
     */
    public function getDealerId()
    {
        return $this->getData(self::KEY_DEALER_ID);
    }

    /**
     * @return string
     */
    public function getDealerName()
    {
        return $this->getData(self::KEY_DEALER_NAME);
    }
    
   
    /**
     * @return string
     */
    public function getCustomerId()
    {
        return $this->getData(self::KEY_CUSTOMER_ID);
    }
   
    /**
     * @return int
     */
    public function getStatus()
    {
        return $this->getData(self::KEY_STATUS);
    }

   

    /**
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(self::KEY_CREATED_AT);
    }

    /**
     * @param string $first_name
     * @return void
     */
    public function setPurchaseId($purchaseid)
    {
        $this->setData(self::KEY_PUR_ID, $purchaseid);
    }

    /**
     * @param string $last_name
     * @return void
     */
    public function setDealerId($dealerid)
    {
        $this->setData(self::KEY_DEALER_ID, $dealerid);
    }

    /**
     * @param string $dealer_name
     * @return void
     */
    public function setDealerName($dealer_name)
    {
        $this->setData(self::KEY_DEALER_NAME, $dealer_name);
    }

    /**
     * @param string $address
     * @return void
     */
    public function setCustomerId($customer_id)
    {
        $this->setData(self::KEY_CUSTOMER_ID, $customer_id);
    }
    

    /**
     * @param int $status
     * @return void
     */
    public function setStatus($status)
    {
        $this->setData(self::KEY_STATUS, $status);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init(ResourceModel::class);
    }

    public function getId()
    {
        return $this->getData(self::KEY_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setId($id)
    {
        return $this->setData(self::KEY_ID, $id);
    }
}
