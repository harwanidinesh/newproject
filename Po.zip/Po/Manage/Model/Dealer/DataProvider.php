<?php

namespace Po\Manage\Model\Dealer;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Model\ResourceModel\Dealer\Collection;
use Po\Manage\Model\ResourceModel\Dealer\CollectionFactory;
use Po\Manage\Model\Dealer;

class DataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();

        /** @var DealerInterface|Dealer $Dealer */
        foreach ($items as $Dealer) {
            $this->loadedData[$Dealer->getId()] = $Dealer->getData();
        }

        return $this->loadedData;
    }
}
