<?php

namespace Po\Manage\Model\Repository;

use Exception;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Model\AbstractModel;
use Po\Manage\Api\Data\PoItemInterface;
use Po\Manage\Api\Data\PoItemSearchResultsInterface;
use Po\Manage\Api\Data\PoItemSearchResultsInterfaceFactory as SearchResultFactory;
use Po\Manage\Api\PoItemRepositoryInterface;
use Po\Manage\Model\ResourceModel\PoItem\Collection;
use Po\Manage\Model\PoItemFactory as PoItemFactory;
use Po\Manage\Model\ResourceModel\PoItem\CollectionFactory;
use Po\Manage\Model\ResourceModel\PoItem as PoItemResource;

class PoItemRepository implements PoItemRepositoryInterface
{
    /**
     * @var array
     */
    protected $instances = [];

    /**
     * @var SearchResultFactory
     */
    private $searchResultFactory;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $joinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var PoItemFactory
     */
    private $PoItemFactory;

    /**
     * @var PoItemResource
     */
    private $PoItemResource;

    /**
     * @param SearchResultFactory $searchResultFactory
     * @param CollectionFactory $collectionFactory
     * @param JoinProcessorInterface $joinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param PoItemFactory $PoItemFactory
     * @param PoItemResource $PoItemResource
     */
    public function __construct(
        SearchResultFactory $searchResultFactory,
        CollectionFactory $collectionFactory,
        JoinProcessorInterface $joinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        PoItemFactory $PoItemFactory,
        PoItemResource $PoItemResource
    ) {
        $this->searchResultFactory = $searchResultFactory;
        $this->collectionFactory = $collectionFactory;
        $this->joinProcessor = $joinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->PoItemFactory = $PoItemFactory;
        $this->PoItemResource = $PoItemResource;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return PoItemSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var PoItemSearchResultsInterface $searchResult */
        $searchResult = $this->searchResultFactory->create();

        /** @var Collection $collection */
        $collection = $this->collectionFactory->create();
        $this->joinProcessor->process($collection, PoItemInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResult->setSearchCriteria($searchCriteria);
        $searchResult->setTotalCount($collection->getSize());
        $searchResult->setItems($collection->getItems());

        return $searchResult;
    }

    /**
     * @param PoItemInterface $PoItem
     * @return PoItemInterface
     * @throws LocalizedException
     */
    public function save(PoItemInterface $PoItem)
    {
        /** @var PoItemInterface|AbstractModel $PoItem */
        try {
            $this->PoItemResource->save($PoItem);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(__('Could not save the PoItem: %1', $exception->getMessage()));
        }

        return $PoItem;
    }

    /**
     * @param int $id
     * @return PoItemInterface
     * @throws LocalizedException
     */
    public function getById($id)
    {
        if (!isset($this->_instances[$id])) {
            /** @var PoItemInterface|AbstractModel $PoItem */
            $PoItem = $this->PoItemFactory->create();
            $this->PoItemResource->load($PoItem, $id);
            if (!$PoItem->getId()) {
                throw new NoSuchEntityException(__('PoItem does not exist'));
            }
            $this->instances[$id] = $PoItem;
        }

        return $this->instances[$id];
    }

    /**
     * @param PoItemInterface $PoItem
     * @return bool
     * @throws LocalizedException
     */
    public function delete(PoItemInterface $PoItem)
    {
        /** @var PoItemInterface|AbstractModel $PoItem */
        $id = $PoItem->getId();
        try {
            unset($this->instances[$id]);
            $this->PoItemResource->delete($PoItem);
        } catch (Exception $e) {
            throw new StateException(__('Unable to remove PoItem %1', $id));
        }
        unset($this->instances[$id]);

        return true;
    }

    /**
     * @param int $id
     * @return bool
     * @throws LocalizedException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
