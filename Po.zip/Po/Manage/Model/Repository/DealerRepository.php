<?php

namespace Po\Manage\Model\Repository;

use Exception;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Model\AbstractModel;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Api\Data\DealerSearchResultsInterface;
use Po\Manage\Api\Data\DealerSearchResultsInterfaceFactory as SearchResultFactory;
use Po\Manage\Api\DealerRepositoryInterface;
use Po\Manage\Model\ResourceModel\Dealer\Collection;
use Po\Manage\Model\DealerFactory as DealerFactory;
use Po\Manage\Model\ResourceModel\Dealer\CollectionFactory;
use Po\Manage\Model\ResourceModel\Dealer as DealerResource;

class DealerRepository implements DealerRepositoryInterface
{
    /**
     * @var array
     */
    protected $instances = [];

    /**
     * @var SearchResultFactory
     */
    private $searchResultFactory;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $joinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var DealerFactory
     */
    private $DealerFactory;

    /**
     * @var DealerResource
     */
    private $DealerResource;

    /**
     * @param SearchResultFactory $searchResultFactory
     * @param CollectionFactory $collectionFactory
     * @param JoinProcessorInterface $joinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param DealerFactory $DealerFactory
     * @param DealerResource $DealerResource
     */
    public function __construct(
        SearchResultFactory $searchResultFactory,
        CollectionFactory $collectionFactory,
        JoinProcessorInterface $joinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        DealerFactory $DealerFactory,
        DealerResource $DealerResource
    ) {
        $this->searchResultFactory = $searchResultFactory;
        $this->collectionFactory = $collectionFactory;
        $this->joinProcessor = $joinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->DealerFactory = $DealerFactory;
        $this->DealerResource = $DealerResource;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return DealerSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var DealerSearchResultsInterface $searchResult */
        $searchResult = $this->searchResultFactory->create();

        /** @var Collection $collection */
        $collection = $this->collectionFactory->create();
        $this->joinProcessor->process($collection, DealerInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResult->setSearchCriteria($searchCriteria);
        $searchResult->setTotalCount($collection->getSize());
        $searchResult->setItems($collection->getItems());

        return $searchResult;
    }

    /**
     * @param DealerInterface $Dealer
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function save(DealerInterface $Dealer)
    {
        /** @var DealerInterface|AbstractModel $Dealer */
        try {
            $this->DealerResource->save($Dealer);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(__('Could not save the Dealer: %1', $exception->getMessage()));
        }

        return $Dealer;
    }

    /**
     * @param int $id
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function getById($id)
    {
        if (!isset($this->_instances[$id])) {
            /** @var DealerInterface|AbstractModel $Dealer */
            $Dealer = $this->DealerFactory->create();
            $this->DealerResource->load($Dealer, $id);
            if (!$Dealer->getId()) {
                throw new NoSuchEntityException(__('Dealer does not exist'));
            }
            $this->instances[$id] = $Dealer;
        }

        return $this->instances[$id];
    }

    /**
     * @param DealerInterface $Dealer
     * @return bool
     * @throws LocalizedException
     */
    public function delete(DealerInterface $Dealer)
    {
        /** @var DealerInterface|AbstractModel $Dealer */
        $id = $Dealer->getId();
        try {
            unset($this->instances[$id]);
            $this->DealerResource->delete($Dealer);
        } catch (Exception $e) {
            throw new StateException(__('Unable to remove Dealer %1', $id));
        }
        unset($this->instances[$id]);

        return true;
    }

    /**
     * @param int $id
     * @return bool
     * @throws LocalizedException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
