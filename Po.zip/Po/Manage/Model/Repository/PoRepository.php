<?php

namespace Po\Manage\Model\Repository;

use Exception;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Model\AbstractModel;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Api\Data\PoSearchResultsInterface;
use Po\Manage\Api\Data\PoSearchResultsInterfaceFactory as SearchResultFactory;
use Po\Manage\Api\PoRepositoryInterface;
use Po\Manage\Model\ResourceModel\Po\Collection;
use Po\Manage\Model\PoFactory as PoFactory;
use Po\Manage\Model\ResourceModel\Po\CollectionFactory;
use Po\Manage\Model\ResourceModel\Po as PoResource;

class PoRepository implements PoRepositoryInterface
{
    /**
     * @var array
     */
    protected $instances = [];

    /**
     * @var SearchResultFactory
     */
    private $searchResultFactory;

    /**
     * @var CollectionFactory
     */
    private $collectionFactory;

    /**
     * @var JoinProcessorInterface
     */
    private $joinProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var PoFactory
     */
    private $PoFactory;

    /**
     * @var PoResource
     */
    private $PoResource;

    /**
     * @param SearchResultFactory $searchResultFactory
     * @param CollectionFactory $collectionFactory
     * @param JoinProcessorInterface $joinProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     * @param PoFactory $PoFactory
     * @param PoResource $PoResource
     */
    public function __construct(
        SearchResultFactory $searchResultFactory,
        CollectionFactory $collectionFactory,
        JoinProcessorInterface $joinProcessor,
        CollectionProcessorInterface $collectionProcessor,
        PoFactory $PoFactory,
        PoResource $PoResource
    ) {
        $this->searchResultFactory = $searchResultFactory;
        $this->collectionFactory = $collectionFactory;
        $this->joinProcessor = $joinProcessor;
        $this->collectionProcessor = $collectionProcessor;
        $this->PoFactory = $PoFactory;
        $this->PoResource = $PoResource;
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return PoSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var PoSearchResultsInterface $searchResult */
        $searchResult = $this->searchResultFactory->create();

        /** @var Collection $collection */
        $collection = $this->collectionFactory->create();
        $this->joinProcessor->process($collection, PoInterface::class);
        $this->collectionProcessor->process($searchCriteria, $collection);
        $searchResult->setSearchCriteria($searchCriteria);
        $searchResult->setTotalCount($collection->getSize());
        $searchResult->setItems($collection->getItems());

        return $searchResult;
    }

    /**
     * @param PoInterface $Po
     * @return PoInterface
     * @throws LocalizedException
     */
    public function save(PoInterface $Po)
    {
        /** @var PoInterface|AbstractModel $Po */
        try {
            $this->PoResource->save($Po);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(__('Could not save the Po: %1', $exception->getMessage()));
        }

        return $Po;
    }

    /**
     * @param int $id
     * @return PoInterface
     * @throws LocalizedException
     */
    public function getById($id)
    {
        if (!isset($this->_instances[$id])) {
            /** @var PoInterface|AbstractModel $Po */
            $Po = $this->PoFactory->create();
            $this->PoResource->load($Po, $id);
            if (!$Po->getId()) {
                throw new NoSuchEntityException(__('Po does not exist'));
            }
            $this->instances[$id] = $Po;
        }

        return $this->instances[$id];
    }

    /**
     * @param PoInterface $Po
     * @return bool
     * @throws LocalizedException
     */
    public function delete(PoInterface $Po)
    {
        /** @var PoInterface|AbstractModel $Po */
        $id = $Po->getId();
        try {
            unset($this->instances[$id]);
            $this->PoResource->delete($Po);
        } catch (Exception $e) {
            throw new StateException(__('Unable to remove Po %1', $id));
        }
        unset($this->instances[$id]);

        return true;
    }

    /**
     * @param int $id
     * @return bool
     * @throws LocalizedException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}
