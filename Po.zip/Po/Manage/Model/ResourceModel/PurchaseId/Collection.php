<?php
/**
 * Copyright © 2015 EmizenTech. All rights reserved.
 */

namespace Po\Manage\Model\Resource\PurchaseId;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Po\Manage\Model\PurchaseId', 'Po\Manage\Model\ResourceModel\PurchaseId');
    }
}
