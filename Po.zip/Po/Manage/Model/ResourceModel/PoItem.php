<?php

namespace Po\Manage\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Po\Manage\Api\Data\PoItemInterface;

class PoItem extends AbstractDb
{
    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init('po_table', PoItemInterface::KEY_ID);
    }
}
