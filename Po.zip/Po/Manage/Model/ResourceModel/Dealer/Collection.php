<?php

namespace Po\Manage\Model\ResourceModel\Dealer;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Po\Manage\Model\Dealer as Model;
use Po\Manage\Model\ResourceModel\Dealer as ResourceModel;
use Po\Manage\Api\Data\DealerInterface;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = DealerInterface::KEY_ID;

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
