<?php
/**
 * Copyright © 2015 EmizenTech. All rights reserved.
 */

namespace Po\Manage\Model\ResourceModel;

class PurchaseId extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('po_custompurchaseorder', 'id');
    }
}

