<?php

namespace Po\Manage\Model;

use Magento\Framework\Model\AbstractModel;
use Po\Manage\Api\Data\PoItemInterface;
use Po\Manage\Model\ResourceModel\PoItem as ResourceModel;

class PoItem extends AbstractModel implements PoItemInterface
{
    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'sc_po';

    /**
     * Parameter name in event
     * In observe method you can use $observer->getEvent()->getRule() in this case
     *
     * @var string
     */
    protected $_eventObject = 'po';
    
    /**
     * @return string
     */
    public function getPurchaseId()
    {
        return $this->getData(self::KEY_PUR_ID);
    }

    /**
     * @return string
     */
    public function getProductId()
    {
        return $this->getData(self::KEY_PRODUCT_ID);
    }

    /**
     * @return string
     */
    public function getProductName()
    {
        return $this->getData(self::KEY_PRODUCT_NAME);
    }
    
   
    /**
     * @return string
     */
    public function getQty()
    {
        return $this->getData(self::KEY_QTY);
    }
   
    /**
     * @return int
     */
    public function getRemarks()
    {
        return $this->getData(self::KEY_REMARKS);
    }

    /**
     * @param string $first_name
     * @return void
     */
    public function setPurchaseId($purchaseid)
    {
        $this->setData(self::KEY_PUR_ID, $purchaseid);
    }

    /**
     * @param string $last_name
     * @return void
     */
    public function setProductId($productid)
    {
        $this->setData(self::KEY_PRODUCT_ID, $productid);
    }

    /**
     * @param string $dealer_name
     * @return void
     */
    public function setProductName($productName)
    {
        $this->setData(self::KEY_PRODUCT_NAME, $productName);
    }

    /**
     * @param string $address
     * @return void
     */
    public function setQty($qty)
    {
        $this->setData(self::KEY_QTY, $qty);
    }
    

    /**
     * @param int $status
     * @return void
     */
    public function setRemarks($remarks)
    {
        $this->setData(self::KEY_REMARKS, $remarks);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->_init(ResourceModel::class);
    }

    public function getId()
    {
        return $this->getData(self::KEY_ID);
    }

    /**
     * {@inheritdoc}
     */
    public function setId($id)
    {
        return $this->setData(self::KEY_ID, $id);
    }
}
