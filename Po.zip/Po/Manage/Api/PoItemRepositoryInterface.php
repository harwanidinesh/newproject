<?php

namespace Po\Manage\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Po\Manage\Api\Data\PoItemInterface;
use Po\Manage\Api\Data\PoItemSearchResultsInterface;

interface PoItemRepositoryInterface
{
    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return ReviewSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @param DealerInterface $dealer
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function save(PoItemInterface $poItem);

    /**
     * @param int $id
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function getById($id);

    /**
     * @param DealerInterface $poItem
     * @return bool
     * @throws LocalizedException
     */
    public function delete(PoItemInterface $poItem);

    /**
     * @param int $id
     * @return bool
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function deleteById($id);



}
