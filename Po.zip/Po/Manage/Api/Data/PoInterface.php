<?php

namespace Po\Manage\Api\Data;

interface PoInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const KEY_ID         = 'id';
    const KEY_PUR_ID     = 'purchase_id';
    const KEY_DEALER_ID = 'dealer_id';
    const KEY_DEALER_NAME    = 'dealer_name';
    const KEY_CUSTOMER_ID    = 'customer_id';
    const KEY_STATUS     = 'status';
    const KEY_CREATED_AT = 'created_at';
   

    /**
     * @return string
     */
    public function getPurchaseId();

    /**
     * @return string
     */
    public function getDealerId();

    /**
     * @return string
     */
    public function getDealerName();

    /**
     * @return string
     */
    public function getCustomerId();
    

    /**
     * @return int
     */
    public function getStatus();

  

    /**
     * @return string
     */
    public function getCreatedAt();

    /**
     * @param string $first_name
     * @return void
     */
    public function setPurchaseId($purchaseid);

    /**
     * @param string $last_name
     * @return void
     */
    public function setDealerId($dealerid);

    /**
     * @param string $dealer_name
     * @return void
     */
    public function setDealerName($dealer_name);

    /**
     * @param string $address
     * @return void
     */
    public function setCustomerId($customer_id);
    
    
    /**
     * @param int $status
     * @return void
     */
    public function setStatus($status);

    /**
     * @return $id
     */
    public function getId();
    
    /**
     * @param int $id
     * @return void
     */
    public function setId($id);

}
