<?php

namespace Po\Manage\Api\Data;

interface PoItemInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const KEY_ID         = 'id';
    const KEY_PUR_ID     = 'purchase_id';
    const KEY_PRODUCT_ID = 'product_id';
	const KEY_PRODUCT_NAME = 'product_name';
    const KEY_QTY    = 'qty';
    const KEY_REMARKS   = 'remarks';
   
   

    /**
     * @return string
     */
    public function getPurchaseId();

    /**
     * @return string
     */
    public function getProductId();
	
	/**
     * @return string
     */
    public function getProductName();

    /**
     * @return string
     */
    public function getQty();

    /**
     * @return string
     */
    public function getRemarks();
    

    
    /**
     * @param string $first_name
     * @return void
     */
    public function setPurchaseId($purchaseid);

    /**
     * @param string $last_name
     * @return void
     */
    public function setProductId($productid);
	
	/**
     * @param string $last_name
     * @return void
     */
    public function setProductName($productName);

    /**
     * @param string $dealer_name
     * @return void
     */
    public function setQty($qty);

    /**
     * @param string $address
     * @return void
     */
    public function setRemarks($remarks);
    

    /**
     * @return $id
     */
    public function getId();
    
    /**
     * @param int $id
     * @return void
     */
    public function setId($id);

}
