<?php

namespace Po\Manage\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface PoItemSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get list.
     *
     * @return PoItemInterface[]
     */
    public function getItems();

    /**
     * Set list.
     *
     * @param PoItemInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
