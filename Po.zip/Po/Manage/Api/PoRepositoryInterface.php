<?php

namespace Po\Manage\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Po\Manage\Api\Data\PoInterface;
use Po\Manage\Api\Data\PoSearchResultsInterface;

interface PoRepositoryInterface
{
    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return ReviewSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @param PoInterface $po
     * @return PoInterface
     * @throws LocalizedException
     */
    public function save(PoInterface $po);

    /**
     * @param int $id
     * @return PoInterface
     * @throws LocalizedException
     */
    public function getById($id);

    /**
     * @param PoInterface $po
     * @return bool
     * @throws LocalizedException
     */
    public function delete(PoInterface $po);

    /**
     * @param int $id
     * @return bool
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function deleteById($id);



}
