<?php

namespace Po\Manage\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Po\Manage\Api\Data\DealerInterface;
use Po\Manage\Api\Data\DealerSearchResultsInterface;

interface DealerRepositoryInterface
{
    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return ReviewSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * @param DealerInterface $dealer
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function save(DealerInterface $dealer);

    /**
     * @param int $id
     * @return DealerInterface
     * @throws LocalizedException
     */
    public function getById($id);

    /**
     * @param DealerInterface $dealer
     * @return bool
     * @throws LocalizedException
     */
    public function delete(DealerInterface $dealer);

    /**
     * @param int $id
     * @return bool
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function deleteById($id);



}
