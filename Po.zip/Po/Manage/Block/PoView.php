<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\PoFactory;
use CrudExample\CustomModule\Model\DealerFactory as PoDataFactory;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Sales\Model\Order\Address\Renderer as AddressRenderer;
use Po\Manage\Model\ResourceModel\PoItem\CollectionFactory as PoItemCollectionFactory;
/**
 * Po View block
 */
class PoView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Po
     */
    protected $_book;
    public function __construct(
        Context $context,
        PoFactory $poFactory,
        PoDataFactory $poDataFactory,
        AddressRenderer $addressRenderer,
        PoItemCollectionFactory $poItemCollectionFactory,
        \Magento\Customer\Api\AccountManagementInterface $accountManagement,
        \Magento\Customer\Model\Address\Config $addressConfig,
        \Magento\Customer\Model\Address\Mapper $addressMapper,
        FilterProvider $filterProvider
    ) {
        $this->_poFactory = $poFactory;
        $this->_poDataFactory = $poDataFactory;
        $this->_filterProvider = $filterProvider;
        $this->addressRenderer = $addressRenderer;
        $this->_poItemCollectionFactory = $poItemCollectionFactory;
        $this->accountManagement = $accountManagement;
        $this->_addressConfig = $addressConfig;
        $this->addressMapper = $addressMapper;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Po View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $po = $this->_poFactory->create();
        $singleData = $po->load($id);
        if($singleData->getId()){
            return $singleData;
        }else{
            return false;
        }
    }

    public function getDefaultShippingAddress($customerId)
    {
        try {
            $address = $this->accountManagement->getDefaultShippingAddress($customerId);
        } catch (NoSuchEntityException $e) {
            return __('You have not set a default billing address.');
        }
        return $address;
    }

    /* Html Format */
    public function getDefaultShippingAddressHtml($customerId) {
        $address = $this->getDefaultShippingAddress($customerId);
        if ($address) {
            return $this->_getAddressHtml($address);
        } else {
            return __('You have not set a default Shipping address.');
        }
    }

    public function getPoAddress($poId)
    {
        $po = $this->_poDataFactory->create();
        $singleData = $po->load($poId);
        if($singleData->getId()){
                $address['street'] = $singleData['address'];
                $address['city'] = $singleData['city'];
                $address['region'] = $singleData['state'];
                $address['country_id'] = "IN";
                return $address;
        }else{
            return __('Po address is not save.');
        }
    }

    public function getFormattedAddress($poId)
    {
        $address = $this->getPoAddress($poId);
        $renderer = $this->_addressConfig->getFormatByCode('html')->getRenderer();
        return $renderer->renderArray($address);
    }

    protected function _getAddressHtml($address)
    {
        /** @var \Magento\Customer\Block\Address\Renderer\RendererInterface $renderer */
        $renderer = $this->_addressConfig->getFormatByCode('html')->getRenderer();
        return $renderer->renderArray($this->addressMapper->toFlatArray($address));
    }

    public function getItems($poId)
    {
        $collection = $this->_poItemCollectionFactory->create();
        $collection->addFieldToFilter('purchase_id', array('eq' => array($poId)));
        if($collection->getSize()>0)
        {
            return $collection;
        }
    }
}
