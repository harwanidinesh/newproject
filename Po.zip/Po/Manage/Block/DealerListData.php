<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\DealerFactory;
/**
 * dealer List block
 */
class DealerListData extends \Magento\Framework\View\Element\Template
{
    /**
     * @var dealer
     */
    protected $_dealer;
    public function __construct(
        Context $context,
        DealerFactory $dealer
    ) {
        $this->_dealer = $dealer;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Po List Page'));
        
        if ($this->getdealerCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'dealer.crud.pager'
            )->setAvailableLimit(array(5=>5,10=>10,15=>15))->setShowPerPage(true)->setCollection(
                $this->getdealerCollection()
            );
            $this->setChild('pager', $pager);
            $this->getdealerCollection()->load();
        }
        return parent::_prepareLayout();
    }

    public function getDealerCollection()
    {
        $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 5;

        $dealer = $this->_dealer->create();
        $collection = $dealer->getCollection();
       
        //$dealer->setOrder('dealer_id','ASC');
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}
