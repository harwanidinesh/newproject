<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Po\Manage\Block;

use Magento\Customer\Model\Context;
use Po\Manage\Model\PoFactory;
use Po\Manage\Model\Po;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Session\SessionManagerInterface;

/**
 * One page checkout success page
 *
 * @api
 * @since 100.0.2
 */
class Success extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_coreSession;

    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $_orderConfig;

    /**
     * @var \Magento\Framework\App\Http\Context
     */
    protected $httpContext;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Sales\Model\Order\Config $orderConfig
     * @param \Magento\Framework\App\Http\Context $httpContext
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        SessionManagerInterface $session,
        PoFactory $poFacotry,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\Http\Context $httpContext,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_coreSession = $session;
        $this->_poFacotry = $poFacotry;
        $this->scopeConfig = $scopeConfig;
        $this->httpContext = $httpContext;
    }

    /**
     * Initialize data and prepare it for output
     *
     * @return string
     */
    protected function _beforeToHtml()
    {
        $this->prepareBlockData();
        return parent::_beforeToHtml();
    }

    /**
     * Prepares block data
     *
     * @return void
     */
    protected function prepareBlockData()
    {
        $po = $this->_coreSession->getLastRealPo();

        $this->addData(
            [
                'is_order_visible' => $this->isVisible($po),
                'view_purchase_url' => $this->getUrl(
                    'pur/index/viewpo/',
                    ['id' => $po->getId()]
                ),
                'print_url' => $this->getUrl(
                    'pur/index/print',
                    ['id' => $po->getId()]
                ),
                'can_print_order' => $this->isVisible($po),
                'can_view_order'  => $this->canViewOrder($po),
                'purchase_id'  => $po->getPurchaseId()
            ]
        );
    }
    
    public function getRealPurchaseId()
    {
        /** @var \Magento\Sales\Model\Order $order */
        $po = $this->_poFacotry->create()->load($this->_coreSession->getPurchaseId());
        return $po->getPurchaseId();
    }

    /**
     * Is order visible
     *
     * @param Order $order
     * @return bool
     */
    protected function isVisible(Po $po)
    {
        return !in_array(
            $po->getStatus(),
            ['complete','cancel']
        );
    }

    /**
     * Can view order
     *
     * @param Order $order
     * @return bool
     */
    protected function canViewOrder(Po $po)
    {
        return $this->httpContext->getValue(Context::CONTEXT_AUTH)
            && $this->isVisible($po);
    }

    /**
     * @return string
     * @since 100.2.0
     */
    public function getContinueUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }
    
    public function getCanViewPurchase()
    {
        return $this->scopeConfig->getValue('manage_po/pur_order/enabled', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}
