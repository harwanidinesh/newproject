<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\DealerFactory;

class EditView extends \Magento\Framework\View\Element\Template
{
     /**
     * @var Dealer
     */
    protected $_dealer;
    public function __construct(
        Context $context,
        DealerFactory $dealer
    ) {
        $this->_dealer = $dealer;
        parent::__construct($context);
    }

  
    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Dealer Edit Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $dealer = $this->_dealer->create();
        $singleData = $dealer->load($id);
        if($singleData->getId() && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}
