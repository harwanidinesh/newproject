<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\PoFactory;

class EditView extends \Magento\Framework\View\Element\Template
{
     /**
     * @var Po
     */
    protected $_po;
    public function __construct(
        Context $context,
        PoFactory $po
    ) {
        $this->_po = $po;
        parent::__construct($context);
    }

  
    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Po Edit Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $po = $this->_po->create();
        $singleData = $po->load($id);
        if($singleData->getId() && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}
