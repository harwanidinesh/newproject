<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\PoFactory;
/**
 * po List block
 */
class PoListData extends \Magento\Framework\View\Element\Template
{
    /**
     * @var po
     */
    protected $_po;
    public function __construct(
        Context $context,
        PoFactory $po
    ) {
        $this->_po = $po;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Po List Page'));
        
        if ($this->getpoCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'po.crud.pager'
            )->setAvailableLimit(array(5=>5,10=>10,15=>15))->setShowPerPage(true)->setCollection(
                $this->getpoCollection()
            );
            $this->setChild('pager', $pager);
            $this->getpoCollection()->load();
        }
        return parent::_prepareLayout();
    }

    public function getPoCollection()
    {
        $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 5;

        $po = $this->_po->create();
        $collection = $po->getCollection();
       
        //$po->setOrder('po_id','ASC');
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}
