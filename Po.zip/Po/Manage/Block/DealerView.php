<?php

namespace Po\Manage\Block;

use Magento\Framework\View\Element\Template\Context;
use Po\Manage\Model\DealerFactory;
use Magento\Cms\Model\Template\FilterProvider;
/**
 * Dealer View block
 */
class DealerView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Dealer
     */
    protected $_book;
    public function __construct(
        Context $context,
        DealerFactory $book,
        FilterProvider $filterProvider
    ) {
        $this->_book = $book;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Dealer View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $book = $this->_book->create();
        $singleData = $book->load($id);
        if($singleData->getId() && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}
