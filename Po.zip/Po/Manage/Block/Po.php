<?php

namespace Po\Manage\Block;

use CrudExample\CustomModule\Model\DealerFactory; 

/**
 * Crudimage content block
 */
class Po extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
		DealerFactory $dealer
    ) {
        parent::__construct($context);
		$this->_dealer = $dealer;
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Po'));
        
        return parent::_prepareLayout();
    }
	
	public function getDealerCollection()
    {
        $dealer = $this->_dealer->create();
        $collection = $dealer->getCollection();
        $collection->addFieldToFilter('status','1');

        return $collection;
    }
	
	public function dealerSelectList()
	{
		$html = "<option value = ''>Please Select the dealer name</option>";
		$dealerCollection = $this->getDealerCollection();
		foreach($dealerCollection as $key => $data)
		{
				$html = $html."<option value = '".$data->getId()."'>".$data->getDealerName()."</option>";
		}
		return $html;
	}
}
